# EmulsiPred
Prediction of Emulsifying Peptides
